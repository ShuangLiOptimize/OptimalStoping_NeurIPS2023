import os
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import numpy as np
import random
# from random import seed, random, sample
from functions.functions import *
import matplotlib.pyplot as plt
from utils import latin_hypercube
from utils import from_unit_cube
from Turbo1 import Turbo1
import joblib
import multiprocessing as mp
from utils import from_unit_cube, latin_hypercube, to_unit_cube
from Metric import *
from sklearn.cluster import KMeans
from copy import deepcopy
from operator import itemgetter
import re

import gpytorch
import torch
from torch.quasirandom import SobolEngine
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, RationalQuadratic, ExpSineSquared, RBF, DotProduct
from sklearn.preprocessing import power_transform
import GPy
import GPyOpt
from scipy import stats
import vegas
import scipy
from scipy.optimize import minimize
import autograd.numpy
from autograd import grad as GRAD
from scipy.spatial.distance import pdist, squareform
from scipy.special import comb
from itertools import combinations

def auto_save_file(path):
    directory, file_name = os.path.split(path)
    while os.path.isfile(path):
        pattern = '(\d+)\)\.'
        if re.search(pattern, file_name) is None:
            file_name = file_name.replace('.', '(1).')
        else:
            current_number = np.int(re.findall(pattern, file_name)[-1])
            new_number = current_number + 1
            file_name = file_name.replace(f'({current_number}).', f'({new_number}).')
        path = os.path.join(directory + os.sep + file_name)
    return path

def Convexity_test(device, dtype, ConvexTestSet, Next, X, ACF, ymin):
    j = 0
    number_test = 0
    number_convex = 0
    min_cuda = 1024
    if len(X) < min_cuda:
        device, dtype = torch.device("cpu"), torch.float64
    else:
        device, dtype = device, dtype
    # combines = comb(len(ConvexTestSet),2)
    combines = [c for c in combinations(range(len(ConvexTestSet)),2)]
    # ConvexTestSet = ConvexTestSet[1:len(ConvexTestSet),:]
    for i1 in range(0, len(combines)):
        X1 = ConvexTestSet[combines[i1][0], :]
        X2 = ConvexTestSet[combines[i1][1], :]
        X3 = (X1 + X2) / 2
        X1 = np.asarray(X1).reshape(1, -1)
        X2 = np.asarray(X2).reshape(1, -1)
        X3 = np.asarray(X3).reshape(1, -1)
        X_torch1 = torch.tensor(X1).to(device=device, dtype=dtype)
        X_torch2 = torch.tensor(X2).to(device=device, dtype=dtype)
        X_torch3 = torch.tensor(X3).to(device=device, dtype=dtype)
        y_means1 = Next.GP.likelihood(Next.GP(X_torch1)).mean[0]
        y_vars1 = Next.GP.likelihood(Next.GP(X_torch1)).variance[0]
        y_means2 = Next.GP.likelihood(Next.GP(X_torch2)).mean[0]
        y_vars2 = Next.GP.likelihood(Next.GP(X_torch2)).variance[0]
        y_means3 = Next.GP.likelihood(Next.GP(X_torch3)).mean[0]
        y_vars3 = Next.GP.likelihood(Next.GP(X_torch3)).variance[0]
        Norm_Distribution = torch.distributions.normal.Normal(torch.tensor([0.0]), torch.tensor([1.0]))
        f1 = y_means1.detach().numpy()
        f2 = y_means2.detach().numpy()
        f3 = y_means3.detach().numpy()
        if (f1 + f2) / 2 > f3 or abs((f1 + f2) / 2 - f3) < 1e-5:
            number_convex = number_convex + 1
        number_test = number_test + 1

        # if number_test > len(np.asarray(X1).reshape(-1)) * 10:
        #     break
        j = j + 1
    if number_test < 1:
        a = 0
    convex_rate = number_convex / number_test
    return convex_rate


def Approximate_LowerBound(device, dtype, DataSet, Next, lb, ub, x_best, mu, sigma):

    def MU(Xc):
        X_best = np.asarray(Xc).reshape(-1)
        X_torch = torch.tensor(X_best, requires_grad=True).to(device=device, dtype=dtype)
        # y_vars = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).variance.detach().numpy()
        y_means = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).mean.detach().numpy()
        y_means = mu + sigma * y_means
        return y_means[0]

    def Negative_MU(Xc):
        X_best = np.asarray(Xc).reshape(-1)
        X_torch = torch.tensor(X_best, requires_grad=True).to(device=device, dtype=dtype)
        # y_vars = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).variance.detach().numpy()
        y_means = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).mean.detach().numpy()
        y_means = mu + sigma * y_means
        return y_means[0]*-1

    def Var(Xc):
        X_best = np.asarray(Xc).reshape(-1)
        X_torch = torch.tensor(X_best, requires_grad=True).to(device=device, dtype=dtype)
        y_vars = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).variance.detach().numpy()
        # y_means = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).mean.detach().numpy()
        return y_vars[0]*-1

    def LCB(Xc):
        # Xc = np.array(Xc)
        # X_best = to_unit_cube(deepcopy(Xc), self.sub_lb.min(), self.sub_ub.max())
        X_best = np.asarray(Xc).reshape(-1)
        X_torch = torch.tensor(X_best, requires_grad=True).to(device=device, dtype=dtype)
        y_vars = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).variance.detach().numpy()
        y_means = Next.GP.likelihood(Next.GP(X_torch.unsqueeze(dim=0))).mean.detach().numpy()
        y_means = mu + sigma * y_means
        conf_intveral = norm.interval(0.95, loc=y_means, scale=y_vars)
        return conf_intveral[0]


    def Dist(Xc):
        XC = np.tile(Xc,[len(DataSet),1])
        XC = np.array(XC)
        dist = DataSet-XC
        dist = np.square(dist)
        dist = np.sum(dist, axis=1)
        dist = np.sqrt(dist)
        dist = np.sum(dist)
        return -1*dist

    # Calculate the minimum of the posterior mean function
    lb = np.asarray(lb).reshape(-1)
    ub = np.asarray(ub).reshape(-1)
    lb = to_unit_cube(deepcopy(lb), lb.min(), ub.max())
    ub = to_unit_cube(deepcopy(ub), lb.min(), ub.max())
    bounds = [[a, b] for a, b in zip(lb, ub)]
    x0 = np.asarray(x_best).reshape(-1)
    tol = 1e-10
    res = minimize(MU, x0, method='L-BFGS-B', bounds=bounds, tol=tol)
    mu_min = MU(res.x)

    lb_a = np.min(DataSet, axis=0)
    ub_a = np.max(DataSet, axis=0)
    lb = np.asarray(lb_a).reshape(-1)
    ub = np.asarray(ub_a).reshape(-1)
    bounds_var = [[a, b] for a, b in zip(lb, ub)]
    res0 = minimize(Dist, x0, method='L-BFGS-B', bounds=bounds_var, tol=1e-5)
    x1 = res0.x
    x_var = np.asarray(x1).reshape(-1)
    tol = 1e-10
    res = minimize(Var, x_var, method='L-BFGS-B', bounds=bounds_var, tol=tol)
    var_max = Var(res.x)*-1
    var_x = res.x

    #Calculate the regret
    tol = 1e-10
    x_lcb_init = x0
    bounds_lcb = bounds
    res = minimize(LCB, x_lcb_init, method='L-BFGS-B', bounds=bounds_lcb, tol=tol)
    lcb_min = LCB(res.x)
    x_lcb = np.asarray(res.x).reshape(-1)
    x_lcb = torch.tensor(x_lcb, requires_grad=True).to(device=device, dtype=dtype)
    mu_lcb = Next.GP.likelihood(Next.GP(x_lcb.unsqueeze(dim=0))).mean.detach().numpy()
    mu_lcb  = mu + sigma * mu_lcb
    var_lcb = Next.GP.likelihood(Next.GP(x_lcb.unsqueeze(dim=0))).variance.detach().numpy()
    beta = (mu_lcb-lcb_min)/var_lcb
    regret = var_lcb + var_max + (mu_lcb - mu_min)
    rate = var_max / regret
    regret = beta*(var_lcb+var_max) + (mu_lcb-mu_min)
    # rate = beta*var_max/regret

    return regret, rate, var_x, bounds_var, beta, var_lcb, var_max

def KdTree_BO(func, dims, rerun, ACF, stop_method, regret_tol):
    MFE = 50 * dims  ##Maximum Function Evaluations
    init_num = 5 * dims  ## Number of initial samples
    if func == 'Schwefel':
        fun = Schwefel(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-500) * dims, P(500.0) * dims)
    if func == 'Composition1':
        fun = Composition1(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'Weierstrass':
        fun = Weierstrass(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'ExpRosenbrock':
        fun = ExpRosenbrock(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'ExpSchaffer':
        fun = ExpSchaffer(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'Discus':
        fun = Discus(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'Happycat':
        fun = Happycat(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'HGBat':
        fun = HGBat(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'BentCigar':
        fun = BentCigar(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'Elliptic':
        fun = Elliptic(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-100) * dims, P(100.0) * dims)
    if func == 'Ackley':
        fun = Ackley(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-10) * dims, P(5) * dims)
    if func == 'Levy':
        fun = Levy(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-50) * dims, P(50.0) * dims)
    if func == 'Michalewicz':
        fun = Michalewicz(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(0) * dims, P(np.pi) * dims)
    if func == 'Rosenbrock':
        fun = Rosenbrock(dims=dims)
        P = lambda *coords: list(coords)
        bounds = (P(-5) * dims, P(10.0) * dims)
    if func == 'Lunarlanding':
        fun = Lunarlanding()
        dims = fun.dims
        lb = fun.lb.tolist()
        ub = fun.ub.tolist()
        bounds = [lb, ub]
    if func == 'Swimmer':
        fun = Swimmer()
        dims = fun.dims
        lb = fun.lb.tolist()
        ub = fun.ub.tolist()
        bounds = [lb, ub]
    if func == 'Hopper':
        fun = Hopper()
        dims = fun.dims
        lb = fun.lb.tolist()
        ub = fun.ub.tolist()
        bounds = [lb, ub]
    if func == 'Walker':
        fun = Walker()
        dims = fun.dims
        lb = fun.lb.tolist()
        ub = fun.ub.tolist()
        bounds = [lb, ub]
    if func == 'HalfCheetah':
        fun = HalfCheetah()
        dims = fun.dims
        lb = fun.lb.tolist()
        ub = fun.ub.tolist()
        bounds = [lb, ub]
    lb = bounds[0]
    ub = bounds[1]

    # plt.show()

    ############################# Initialize
    init_points = latin_hypercube(init_num, dims)
    init_points = from_unit_cube(init_points, np.array(lb), np.array(ub))
    Samples = init_points.tolist()
    for i in range(0, len(Samples)):
        sample = Samples[i]
        obj = fun(np.array(sample))
        sample.append(obj)
        Samples[i] = sample

    FX_all = np.array(Samples)[:, dims:dims + 1]
    ################################ Start BO
    it = init_num
    Noise = np.zeros((1,MFE))
    ConvexRate = np.zeros((1, MFE))
    Beta = np.zeros((1, MFE))
    LCB_var = np.zeros((1, MFE))
    LCB_varmax = np.zeros((1, MFE))
    if stop_method == 'CBOS':
        str0 = str(regret_tol)
        str1 = "tol" + str0
        data_dict = {"CBOS": {str1: {"stop_it": [MFE], "stop_bestfitness": [0]},
                              "samples": [MFE], "regret": np.zeros((1,MFE))}}
    else:
        data_dict = {"CBOS": {"tol0": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol1": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol2": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "samples": [MFE], "regret": np.zeros((1,MFE)),
                            "Noise": np.zeros((1,MFE)), "ConvexRate": np.zeros((1,MFE)),
                            "Beta": np.zeros((1,MFE)), "LCB_var": np.zeros((1,MFE)),
                            "LCB_varmax": np.zeros((1, MFE))},
                     "CB": {"tol0": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol1": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol2": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "samples": [MFE], "regret": np.zeros((1,MFE))},
                     "EI": {"tol0": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol1": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol2": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "samples": [MFE], "regret": np.zeros((1,MFE))},
                     "PI": {"tol0": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol1": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "tol2": {"stop_it": [MFE], "stop_bestfitness": [0]},
                            "samples": [MFE], "regret": np.zeros((1,MFE))},
                     "Cov_i": {"tol0": {"stop_it": [MFE], "stop_bestfitness": [0]},
                               "tol1": {"stop_it": [MFE], "stop_bestfitness": [0]},
                               "tol2": {"stop_it": [MFE], "stop_bestfitness": [0]},
                               "samples": [MFE], "regret": np.zeros((1,MFE))}}

    curr_init = np.array(Samples)
    sub_lb = np.array(lb)
    sub_ub = np.array(ub)
    X_init = curr_init[:, :dims]
    FX_init = curr_init[:, dims:dims + 1]
    X = np.asarray(X_init)
    Y = np.asarray(FX_init)
    FX_local_best = Y.min()

    X_index = 1
    ACF_old = ACF
    PC = 0.90
    bounds = [{'name': 'var_1', 'type': 'continuous', 'domain': (sub_lb[0], sub_ub[0])}]
    for i in range(2, dims + 1):
        bounds = bounds + [{'name': 'var_%d' % i, 'type': 'continuous', 'domain': (sub_lb[i - 1], sub_ub[i - 1])}]
    var_x = 0
    bounds_var = 0
    count = 0
    rate = 0
    while it < MFE-1:
        mu, sigma = np.median(Y), Y.std()
        mfe = 1
        batch_size = 1
        turbo1 = Turbo1(
            bounds_var=bounds_var,
            Vmax_rate=rate,
            var_x=var_x,
            mu=mu,
            sigma=sigma,
            ACF=ACF, # Acquisition Function
            ACF_old=ACF_old,
            gradient_index=X_index, # if X_index==1, switch TurBO to vanilla BO
            It=it,
            X_init=X_init,
            FX_init=FX_init,
            FX_best=FX_init.min(),  # FX_init.min(), #FX_best FX_init_best
            f=fun,  # Handle to objective function
            lb=sub_lb,  # Numpy array specifying lower bounds
            ub=sub_ub,  # Numpy array specifying upper bounds
            sub_lb=sub_lb,  # Numpy array specifying lower bounds
            sub_ub=sub_ub,  # Numpy array specifying upper bounds
            n_init=len(FX_init),  # Number of initial bounds from an Latin hypercube design
            max_evals=mfe,
            succtol=3,
            batch_size=batch_size,  # How large batch size TuRBO uses
            verbose=True,  # Print information from each batch
            use_ard=True,  # Set to true if you want to use ARD for the GP kernel
            max_cholesky_size=2000,  # When we switch from Cholesky to Lanczos
            n_training_steps=50,  # Number of steps of ADAM to learn the hypers
            min_cuda=1024,  # Run on the CPU for small datasets
            device="cpu",  # "cpu" or "cuda"
            dtype="float64",  # float64 or float32
        )

        Next = turbo1.optimize()
        Noise[0, it] = Next.GP.likelihood.noise.detach().numpy()
        it = it + len(Next.FXnew[0:, :]) - len(FX_init)
        X = Next.Xnew.tolist()
        Y = Next.FXnew.tolist()
        X_index = 1
        sub_lb = np.array(sub_lb)  # np.array(lb)
        sub_ub = np.array(sub_ub)  # np.array(ub)
        X_init = np.array(X)
        FX_init = np.array(Y)
        X = np.array(X)
        Y = np.array(Y)

        fx_opt = Next.FXbest
        ###################################
        # Optimal Stopping Rules Based on Convex Optimize Method
        device, dtype = torch.device("cpu"), torch.float64
        Ymin = (Y - mu) / sigma
        Ymin = Ymin.min()
        if fx_opt < FX_local_best:
            FX_local_best = fx_opt
            count = 0
        else:
            count = count + 1

        ConvexTestSet3 = X[-10:-1, :]
        ConvexTestSet3 = to_unit_cube(deepcopy(ConvexTestSet3), sub_lb.min(), sub_ub.max())
        convex_rate = Convexity_test(device, dtype, ConvexTestSet3, Next, X, ACF, Ymin)
        ConvexRate[0,it] = convex_rate

        X_predict = ConvexTestSet3
        X_predict_torch = torch.tensor(X_predict, requires_grad=True).to(device=device, dtype=dtype)
        Y_predict = Next.GP.likelihood(Next.GP(X_predict_torch)).mean.detach().numpy()
        index2 = np.where(Y_predict == Y_predict.min())
        X_best = X_predict[index2[0][0], :]
        X_best = np.asarray(X_best).reshape(-1)

        # calculate local regret, i.e. the \tilde{r} of the main paper
        regret, rate, var_x, bounds_var, beta, var_lcb, var_max = Approximate_LowerBound(device, dtype, ConvexTestSet3, Next, lb, ub,
                                                                 X_best, mu, sigma)
        Beta[0,it] = beta
        LCB_var[0,it] = var_lcb
        LCB_varmax[0,it] = var_max
        if it < MFE - 1:
            regret_all = data_dict[stop_method[0]]["regret"]
            regret_all[0, it] = regret
            data_dict[stop_method[0]]["regret"] = regret_all
        if convex_rate >= PC:
            ################## the condition 1 of the main paper
            for itol in range(0, len(regret_tol[0])):
                str0 = str(itol)
                str1 = "tol" + str0
                toli = regret_tol[0][itol]
                if regret/(beta*Next.GP.likelihood.noise.detach().numpy()) < toli and data_dict[stop_method[0]][str1]["stop_it"][0] == MFE:  # norm2 <= np.sqrt(m * tol):
                    ################## the condition 2 of the main paper
                    stop_it_best = np.where(Y == Y.min())
                    stop_it_best = stop_it_best[0][0]
                    stop_fitness_best = Y[stop_it_best, :]
                    print('stop at it=%d' % it)
                    data_dict[stop_method[0]][str1]["stop_it"] = [it]
                    data_dict[stop_method[0]][str1]["stop_bestfitness"] = stop_fitness_best

        ACF = ACF_old
        if stop_method != 'CBOS':
            for im in range(1, len(stop_method)):
                mfe = 1
                batch_size = 1
                if stop_method[im] == 'CB':
                    ACF_s = 'LCB'
                else:
                    ACF_s = stop_method[im]
                if ACF_s == 'Cov_i':
                    regret = count * -1
                else:
                    turbo1 = Turbo1(bounds_var=bounds_var, Vmax_rate=rate, var_x=var_x, mu=mu, sigma=sigma, ACF=ACF_s,
                                    ACF_old=ACF_old,
                                    gradient_index=X_index, It=it, X_init=X_init, FX_init=FX_init,
                                    FX_best=FX_init.min(),
                                    f=fun, lb=sub_lb, ub=sub_ub, sub_lb=sub_lb, sub_ub=sub_ub,
                                    n_init=len(FX_init),
                                    max_evals=mfe, succtol=3, batch_size=batch_size,
                                    verbose=True, use_ard=True, max_cholesky_size=2000, n_training_steps=50,
                                    min_cuda=1024, device="cpu", dtype="float64")
                    Next1 = turbo1.optimize()
                    regret = abs(Next1.y_cand)
                    if stop_method[im] == 'CB':
                        X_predict = to_unit_cube(deepcopy(X), sub_lb.min(), sub_ub.max())
                        X_predict_torch = torch.tensor(X_predict, requires_grad=True).to(device=device, dtype=dtype)
                        y_means = Next.GP.likelihood(Next.GP(X_predict_torch)).mean.detach().numpy()
                        y_means = mu + sigma * y_means
                        y_vars = Next.GP.likelihood(Next.GP(X_predict_torch)).variance.detach().numpy()
                        y_UCB = norm.interval(0.95, loc=y_means, scale=y_vars)
                        y_UCB = y_UCB[1]
                        regret = abs(y_UCB.min() - Next1.y_cand)
                if it < MFE - 1:
                    data_dict[stop_method[im]]["regret"][0, it] = regret
                for itol in range(0, len(regret_tol[0])):
                    str0 = str(itol)
                    str1 = "tol" + str0
                    toli = regret_tol[im][itol]
                    if stop_method[im] == 'CB':
                        toli = regret_tol[im][itol]
                    if stop_method[im] == 'Cov_i':
                        toli = regret_tol[im][itol] * -1
                    if regret < toli and data_dict[stop_method[im]][str1]["stop_it"][0] == MFE:
                        data_dict[stop_method[im]][str1]["stop_it"] = [it]
                        stop_it_best = np.where(Y == Y.min())
                        stop_it_best = stop_it_best[0][0]
                        stop_fitness_best = Y[stop_it_best, :]
                        data_dict[stop_method[im]][str1]["stop_bestfitness"] = stop_fitness_best


    samplesnew = np.hstack((Next.Xnew.tolist(), Next.FXnew.tolist()))
    if stop_method == 'CBOS':
        str0 = "tol=" + str(regret_tol)
        data_dict[stop_method]["samples"] = samplesnew
        str2 = "CBOS_"+str0+"_"
    else:
        for i in range(0, len(stop_method)):
            if stop_method[i] == 'CBOS':
                data_dict[stop_method[i]]["Noise"] = Noise
                data_dict[stop_method[i]]["ConvexRate"] = ConvexRate
                data_dict[stop_method[i]]["Beta"] = Beta
                data_dict[stop_method[i]]["LCB_var"] = LCB_var
                data_dict[stop_method[i]]["LCB_varmax"] = LCB_varmax
            data_dict[stop_method[i]]["samples"] = samplesnew
        str2 = "Others_"

    ### Save Results
    path = os.path.abspath('..')
    str1 = '\ConvexityBasedOptimalStopping\Results\\'
    str3 = func+"_"+ACF_old
    str4 = "_Dims%d" % dims
    str5 = "_Rerun%d" % rerun
    str6 = ".pkl"
    filename = path + str1 + str2 + str3 + str4 + str5 + str6
    with open(auto_save_file(filename), 'w') as filenamenew:
        str0 = filenamenew.name
        joblib.dump(data_dict, str0)
    return data_dict





if __name__ == "__main__":
    Methods = ['CBOS', 'CB', 'EI', 'PI', 'Cov_i']
    # CBOS is our method
    # CB is Makarova’s method
    # EI is Nguyen’s method
    # PI is Lorenz’s method
    # Cov_i is Naïve method
    ACF = ['EI', 'PI', 'LCB']
    TOLS = [[2.02, 2.05, 2.08], [0.26, 0.62, 0.97], [0.01,0.04,0.06], [0.07,0.2,0.33], [524, 337, 150]]
    # Dims = [10, 102]
    for k4 in range(2, 3):
        acf = ACF[k4]
        for k3 in range(0, 1):
            method = Methods[k3:5]
            tol = TOLS[k3:5]
            # Functions = ['Lunarlanding','Michalewicz', 'Levy', 'Ackley',   'Rosenbrock','BentCigar','ExpRosenbrock']
            # Functions = ['Swimmer', 'Hopper', 'Walker', 'HalfCheetah','Schwefel']
            # Functions = ['Ackley','Schwefel','Levy','Lunarlanding']
            Functions = ['Ackley']
            for k2 in range(0, 1):
                func = Functions[k2]
                if func == 'Lunarlanding':
                    dims = 12  # 12
                else:
                    dims = 1
                Fitness = np.zeros(21).tolist()
                num_cores = int(mp.cpu_count())
                for k0 in range(0, 20):
                    FX = KdTree_BO(func, dims, k0, acf, method, tol)







