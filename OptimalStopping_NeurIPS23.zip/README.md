# K Dimentional Tree!

Programming Language: Python

In this project a KD tree is generated and visualized using python programmaing language.

->Requirements:
  tkinter         ***pip install tkintertable**
  math            ***pip install maths***
  turtle          ***pip install turtle***
  collections     ***pre installed***
  operator        ***pre installed***
  pprint          ***pip install pprint***
  pydot           ***pip install pydot***
  IPython         ***pip install ipython***
*** for oop_kdtree ***
  random
   time
  operator
  collections
  math
  copy

->How its done
tkinter is used for GUI generation 
turtle is used for graphics design

->Description:
Script allows user to add a new node to the tree, delete a node from the tree.
Also, find if a given point is present on the tree.
if the point is not present in tree it will find the nearest node to that point and also displays distance form the give point and node.
Note: the search operation shows results on console.

->Steps for Execution:
Store all the files in same folder
Simply run canvas.py file to start the execution

"oop_kdtree.py" is an object oriented script for generation of Kd tree it also finds the nearest neighbour of the given point.


Note: The project is still under development so updates will be pushed in later future
