import numpy as np
from utils import from_unit_cube, latin_hypercube, to_unit_cube
import gpytorch
import torch
from torch.quasirandom import SobolEngine
from copy import deepcopy
from scipy.stats import norm
import vegas
import math
from sklearn.cluster import KMeans
from operator import itemgetter
import sys
import functools
import operator
sys.path.append("./")
# import EMOC
import matplotlib.pyplot as plt
# import GPyOpt.acquisitions

class MeanObj:
    def __init__(self, dims):
        self.dims = dims
        self.counter = 0

    def __call__(self, x, nf, nc):
        self.counter += 1
        # assert len(x) == self.dims
        # list只能乘正整数n，表示n倍扩展list的意思
        if len(x) == 1:
            x = np.array(x)
            result = x[:,self.dims-1]
        else:
            x = np.array(x)
            s1 = x.shape
            if s1[1] < self.dims:
                result = 0
            else:
                x1 = x[:, self.dims - 1]
                x1 = x1.tolist()
                if len(x1) < 2:
                    A = x
                x = np.array(x)
                # result = np.mean(x[:, self.dims - 1])
                result = np.mean(x1)


        # result = np.min(x[:, self.dims - 1])
        # result = np.max(x[:, self.dims - 1])
        return result

class UCB:
    def __init__(self, dims, c):
        self.dims = dims
        self.counter = 0
        self.c = c #1, 2

    def __call__(self, x, nf, nc, V, sV, allset): #def __call__(self, x, nf, nc):
        self.counter += 1
        # assert len(x) == self.dims
        # # list只能乘正整数n，表示n倍扩展list的意思
        # x = np.array(x)
        # result = np.mean(x[:,self.dims-1]) * -1 + self.c*np.sqrt(np.log(nf)/nc)
        # # result = np.min(x[:, self.dims - 1])
        # # result = np.max(x[:, self.dims - 1])

        if len(x) > 0:
           x = np.array(x)
           fx = x[:,self.dims-1]
        else:
            # x = np.array(x)
            # fx = x[self.dims - 1]
            fx_all = allset[:, self.dims - 1]
            fx = fx_all.max()
        if len(allset.tolist()) > 0:
           fx_all = allset[:,self.dims-1]
        else:
           fx_all = allset[self.dims - 1]
        fx = (fx-fx_all.min())/(fx_all.max()-fx_all.min())
        rate = np.prod(sV/V)
        if rate < 0.00000001:
            rate = 0.00000001
            # curr_num = nc
        # other_num = nf-nc
        # result = np.mean(fx) * -1 + self.c * np.sqrt(np.log(nf) / nc)
        # result = np.mean(fx) * -1 + self.c * np.sqrt(rate)
        # result = np.mean(fx) * -1 + self.c*np.sqrt((np.log(nf)/nc)*rate)
        # result = np.mean(fx) * -1
        result = np.min(fx) * -1
        return result


class UCB_g:
    def __init__(self, dims, c):
        self.dims = dims
        self.counter = 0
        self.c = c #0.01, 1, 2

    # def __call__(self, x, nf, nc, V, sV, allset): #(self, x, nf, nc, rate, allset):
    def __call__(self, x, nf, nc, V, sV, allset, sub_lb, sub_ub, gp1, dims, FX_best, mu, sigma, lb, ub, corlor, X_best):
        self.counter += 1
        # assert len(x) == self.dims
        # list只能乘正整数n，表示n倍扩展list的意思
        # if len(x) > 0:
        #    x = np.array(x)
        #    fx = x[:,self.dims-1]
        # else:
        #     # x = np.array(x)
        #     # fx = x[self.dims - 1]
        #     fx_all = allset[:, self.dims - 1]
        #     fx = fx_all.max()
        # if len(allset.tolist()) > 0:
        #    fx_all = allset[:,self.dims-1]
        # else:
        #    fx_all = allset[self.dims - 1]
        # fx = (fx-fx_all.min())/(fx_all.max()-fx_all.min())
        # rate = np.prod(sV/V)
        # if rate < 0.00000001:
        #     rate = 0.00000001
        #     # curr_num = nc
        # # other_num = nf-nc
        # # result = np.mean(fx) * -1 + self.c * np.sqrt(np.log(nf) / nc)
        # # result = np.mean(fx) * -1 + self.c * np.sqrt(rate)
        # result = np.mean(fx) * -1 + self.c*np.sqrt((np.log(nf)/nc)*rate)
        # result = np.mean(fx) * -1 + self.c * np.sqrt((np.log(nf/V) / (nc/sV)))
        # result = np.min(x[:, self.dims - 1])
        # result = np.max(x[:, self.dims - 1])


        # # metric based on gp and Sobolev sequence
        # num = round(100 * dims)
        # # init_points = latin_hypercube(num, dims)
        # # init_points = from_unit_cube(init_points, np.array(sub_lb), np.array(sub_ub))
        #
        # class_num = round(len(x)/2)
        # if class_num < 2:
        #     class_num = 2
        # if class_num > 10:
        #     class_num = 10
        # kmean = KMeans(n_clusters=class_num)
        # s_num = len(x)
        # Samples_X = np.array(x)
        # Samples_X = Samples_X[:, 0: self.dims - 1]
        # kmean = kmean.fit(Samples_X)  # np.array(Samples_X)
        # plabel = kmean.predict(Samples_X)  # Samples
        #
        # ClassSamples = [[]]
        # ClassSamples = ClassSamples * class_num
        #
        # Samples = np.array(x)
        # for ci in range(0, s_num):
        #     temp = Samples[ci, :]
        #     c_temp = plabel[ci]
        #     Samples_temp = ClassSamples[c_temp]
        #     temp0 = [[]]
        #     temp0[0] = temp.tolist()
        #     Samples_temp = Samples_temp + temp0
        #     ClassSamples[c_temp] = deepcopy(Samples_temp)
        #
        # X_init_best = [[0]]
        # # X_init_best = X_init_best*class_num
        # for ci in range(0, class_num):
        #     temp = ClassSamples[ci]
        #     if len(temp) > 1:
        #         temp.sort(key=itemgetter(dims))
        #         temp0 = temp[0]
        #         X_init_best = X_init_best + [temp0]
        #     else:
        #         X_init_best = X_init_best + [temp[0]]
        # X_init_best = X_init_best[1:]
        # X_init_best = np.array(X_init_best)
        # fx = X_init_best[:, self.dims - 1]
        # xx = X_init_best[:, 0:self.dims - 1]
        # # samplesnum = round(len(x)/2)+1
        # # x = np.array(x)
        # # fx = x[:, self.dims - 1]
        # # x = x[:, 0:self.dims - 1]
        # sumei = 0
        # for i in range(0, class_num):
        #     indbest = fx.argmin().item()
        #     x_center = xx[indbest, :][None, :]
        #     fx[indbest] = np.inf
        #
        #     # Draw a Sobolev sequence in [lb, ub]
        #     device, dtype = torch.device("cpu"), torch.float64
        #     seed = np.random.randint(int(1e6))
        #     sobol = SobolEngine(dims, scramble=True, seed=seed)
        #     pert = sobol.draw(num).to(dtype=dtype, device=device).cpu().detach().numpy()
        #     pert = np.array(sub_lb) + (np.array(sub_ub) - np.array(sub_lb)) * pert
        #     # Create a perturbation mask
        #     # prob_perturb = min(20.0 / dims, 1.0)
        #     prob_perturb = 0.5
        #     mask = np.random.rand(num, dims) <= prob_perturb
        #     ind = np.where(np.sum(mask, axis=1) == 0)[0]
        #     mask[ind, np.random.randint(0, dims - 1, size=len(ind))] = 1
        #     # Create candidate points
        #     X_cand = x_center.copy() * np.ones((num, dims))
        #     X_cand[mask] = pert[mask]
        #     init_points = X_cand
        #
        #     # the GP of GPytorch
        #     # max_cholesky_size = 2000
        #     # device, dtype = torch.device("cpu"), torch.float64
        #     # # X_cand1 = to_unit_cube(deepcopy(init_points), np.array(lb), np.array(ub))
        #     # X_cand1 = init_points
        #     # xi = 0.0000001
        #     # with torch.no_grad(), gpytorch.settings.max_cholesky_size(max_cholesky_size):
        #     #     X_cand_torch1 = torch.tensor(X_cand1).to(device=device, dtype=dtype)
        #     #     # y_cand1 = gp1.likelihood(gp1(X_cand_torch1)).sample(torch.Size([batch_size])).t().cpu().detach().numpy()
        #     #     y_mu = gp1.likelihood(gp1(X_cand_torch1)).mean.numpy()
        #     #     # y_sigma = gp1.likelihood(gp1(X_cand_torch1)).variance.numpy()
        #     #     lower, upper = gp1.likelihood(gp1(X_cand_torch1)).confidence_region()
        #     #     upper = upper.numpy()
        #     #     lower = lower.numpy()
        #     #     y_sigma = (upper-lower)/2
        #     # y_sigma = y_sigma**2
        #
        #     xi = 0.001
        #     X = init_points
        #     X = np.asarray(X).reshape(-1, dims)
        #     y_mu, y_sigma = gp1.predict(X, return_std=True)
        #     # # expected improvement
        #     # # y_mu = mu + sigma * y_mu
        #     # FX_best = (FX_best - mu) / sigma
        #     # imp = FX_best - y_mu - xi
        #     # Z = imp / y_sigma
        #     # ei = imp * norm.cdf(Z) + y_sigma * norm.pdf(Z)
        #     # # ei = np.sort(ei)
        #     # # ei = ei[-1]
        #     # ei = ei.max()
        #
        #     ucb = y_mu * -1 + 0.1 * y_sigma
        #     ucb = np.sort(ucb)
        #     ucb = ucb[-10:]
        #     sumei = sumei + np.sum(ucb)
        # result = sumei #np.mean(ei) #+ self.c*np.sqrt((np.log(nf)/nc)*rate)

        # # metric based on gp and vegas
        sub_lb = np.array(sub_lb)
        sub_ub = np.array(sub_ub)
        sub_lb = to_unit_cube(deepcopy(sub_lb), np.array(lb).min(), np.array(ub).max())
        sub_ub = to_unit_cube(deepcopy(sub_ub), np.array(lb).min(), np.array(ub).max())
        bounds = [[a, b] for a, b in zip(sub_lb, sub_ub)]
        bounds = bounds #+[[FX_best, FX_best + 0.0000001]]

        # FX_best = (FX_best - mu) / sigma
        X_best = to_unit_cube(deepcopy(X_best), np.array(lb).min(), np.array(ub).max())
        X_best = np.asarray(X_best).reshape(-1, len(X_best))
        FX_best, FX_best_sigma = gp1.predict(X_best, return_std=True)
        def EI(x):
            # FX_best = x[-1]
            # x = x[0:(len(x)-1)]
            x = np.asarray(x).reshape(-1, len(x))
            y_mu, y_sigma = gp1.predict(x, return_std=True)
            # y_mu = y_mu*sigma + mu
            # FX_best = (FX_best - mu) / sigma
            # if y_mu > FX_best:
            #     imp = 0
            # else:
            imp = FX_best - y_mu - 0.01
            Z = imp / y_sigma
            # if y_sigma < 0.01:
            #     ei = 0
            # else:
            ei = imp * norm.cdf(Z) + y_sigma * norm.pdf(Z)
            return ei
        def UCB(x):
            # FX_best = x[-1]
            # x = x[0:(len(x)-1)]
            x = np.asarray(x).reshape(-1, len(x))
            y_mu, y_sigma = gp1.predict(x, return_std=True)
            ucb = -1 * (y_mu  - 1 * y_sigma)
            return ucb
        def PI(x):
            # FX_best = x[-1]
            # x = x[0:(len(x)-1)]
            x = np.asarray(x).reshape(-1, len(x))
            y_mu, y_sigma = gp1.predict(x, return_std=True)
            # FX_best = (FX_best - mu) / sigma
            imp = FX_best - y_mu - 0.01
            Z = imp / y_sigma
            pi = norm.cdf(Z)
            return pi

        integ = vegas.Integrator(bounds)
        result = integ(EI, nitn=10, neval=200*dims)
        # std = result[0].sdev
        # result = result[0].mean
        # std_rate = abs(std)

        # # # metric based on moea
        # class MyProblem(EMOC.Problem):
        #     def __init__(self, dec_num, obj_num):
        #         super(MyProblem, self).__init__(dec_num, obj_num)
        #         # lower_bound = [0] * dec_num
        #         self.lower_bound = sub_lb
        #         self.upper_bound = sub_ub
        #         self.count = 0
        #
        #     def CalObj(self, ind):
        #         self.count = self.count + 1
        #         x = ind.dec
        #         x = np.array(x).reshape(-1, len(x))
        #         y_mu, y_sigma = gp1.predict(x, return_std=True)
        #         temp_obj = [0] * self.obj_num
        #         temp_obj[0] = y_mu[0]
        #         temp_obj[1] = -1 * y_sigma[0]
        #
        #         ind.obj = temp_obj
        #
        # # create and set EMOC parameters
        # para = EMOC.EMOCParameters()
        # para.algorithm_name = "MOEAD" #"NSGA2""MOEAD"
        # # para.problem_name = "ZDT1"
        # para.population_num = 100
        # para.decision_num = dims
        # para.objective_num = 2
        # para.max_evaluation = 1500*dims
        # para.output_interval = 10000
        # myProblem = MyProblem(para.decision_num, para.objective_num)
        # para.SetProblem(myProblem)
        # EMOCManager = EMOC.EMOCManager()
        # EMOCManager.SetTaskParameters(para)
        # OBJS = []
        # HV = []
        # for i in range(0, 1):
        #     EMOCManager.Run()
        #     moea_result = EMOCManager.GetResult()
        #     # OBJS = OBJS + moea_result.pop_objs
        #     OBJS = np.array(moea_result.pop_objs)
        #     hv = moea_result.hv
        #     HV = HV+[hv]
        #     # labels = "hv = %f, " % hv
        #     # labels = labels + "ucb = %f, " % result
        #     # plt.scatter(OBJS[:, 0], OBJS[:, 1], c=corlor, marker='*', label=labels)
        # #     plt.legend()
        # # if corlor == 'blue':
        # #    plt.show()
        # result = np.array(HV)
        # result = result.max()

        # OBJS = 0
        return result#[result, std_rate]

class Gumbel:
    def __init__(self, alpha, beta):
        self.beta = beta
        self.alpha = alpha

    def __call__(self, x):
        p = x-self.alpha
        p = p/self.beta
        p = np.exp(-1*np.exp(-p))
        return 1-p