import numpy as np
import gym
import json
import os
import random
# import mujoco_py
import imageio


class tracker:
    def __init__(self, foldername):
        self.counter = 0
        self.results = []
        self.curt_best = float("inf")
        self.foldername = foldername
        try:
            os.mkdir(foldername)
        except OSError:
            print("Creation of the directory %s failed" % foldername)
        else:
            print("Successfully created the directory %s " % foldername)

    def dump_trace(self):
        trace_path = self.foldername + '/result' + str(len(self.results))
        final_results_str = json.dumps(self.results)
        # with open(trace_path, "a") as f:
        #     f.write(final_results_str + '\n')

    def track(self, result):
        if result < self.curt_best:
            self.curt_best = result
        self.results.append(self.curt_best)
        if len(self.results) % 100 == 0:
            self.dump_trace()


class Levy:
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -50 * np.ones(dims)
        self.ub = 50 * np.ones(dims)
        self.tracker = tracker('Levy' + str(dims))

        self.Cp = 10
        self.leaf_size = 8
        self.kernel_type = "poly"
        self.ninits = 40
        self.gamma_type = "auto"
        print("initialize levy at dims:", self.dims)

    def __call__(self, x):
        # assert len(x) == self.dims
        # assert x.ndim == 1
        # assert np.all(x <= self.ub) and np.all(x >= self.lb)
        x = np.asarray(x).reshape(-1)

        w = []
        for idx in range(0, len(x)):
            w.append(1 + (x[idx] - 1) / 4)
        w = np.array(w)

        term1 = (np.sin(np.pi * w[0])) ** 2;

        term3 = (w[-1] - 1) ** 2 * (1 + (np.sin(2 * np.pi * w[-1])) ** 2);

        term2 = 0
        for idx in range(1, len(w)):
            wi = w[idx]
            new = (wi - 1) ** 2 * (1 + 10 * (np.sin(np.pi * wi + 1)) ** 2)
            term2 = term2 + new

        result = term1 + term2 + term3 + random.random()

        return result


class Ackley:
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -20 * np.ones(dims)
        self.ub = 20 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 10
        self.ninits = 40
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        self.counter += 1
        x = np.asarray(x).reshape(-1)
        result = (-20 * np.exp(-0.2 * np.sqrt(np.inner(x, x) / len(x))) - np.exp(
            np.cos(2 * np.pi * x).sum() / len(x)) + 20 + np.e)+ random.random()

        return result

class Lunarlanding:
    def __init__(self):
        self.dims = 12
        self.lb = np.zeros(12)
        self.ub = 2 * np.ones(12)
        self.counter = 0
        self.env = gym.make('LunarLander-v2')
        self.Cp = 50
        self.leaf_size = 10
        self.kernel_type = "poly"
        self.ninits = 40
        self.gamma_type = "scale"

        self.render = False

    def heuristic_Controller(self, s, w):
        angle_targ = s[0] * w[0] + s[2] * w[1]
        if angle_targ > w[2]:
            angle_targ = w[2]
        if angle_targ < -w[2]:
            angle_targ = -w[2]
        hover_targ = w[3] * np.abs(s[0])

        angle_todo = (angle_targ - s[4]) * w[4] - (s[5]) * w[5]
        hover_todo = (hover_targ - s[1]) * w[6] - (s[3]) * w[7]

        if s[6] or s[7]:
            angle_todo = w[8]
            hover_todo = -(s[3]) * w[9]

        a = 0
        if hover_todo > np.abs(angle_todo) and hover_todo > w[10]:
            a = 2
        elif angle_todo < -w[11]:
            a = 3
        elif angle_todo > +w[11]:
            a = 1
        return a

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        total_rewards = []
        for i in range(0, 3):  # controls the number of episode/plays per trial
            state = self.env.reset()
            rewards_for_episode = []
            num_steps = 2000

            for step in range(num_steps):
                if self.render:
                    self.env.render()
                received_action = self.heuristic_Controller(state, x)
                next_state, reward, done, info = self.env.step(received_action)
                rewards_for_episode.append(reward)
                state = next_state
                if done:
                    break

            rewards_for_episode = np.array(rewards_for_episode)
            total_rewards.append(np.sum(rewards_for_episode))
        total_rewards = np.array(total_rewards)
        mean_rewards = np.mean(total_rewards)

        return mean_rewards * -1


class GrieWank:
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -600 * np.ones(dims)  # [-600, 600]
        self.ub = 600 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        I = np.linspace(1, self.dims, num=self.dims)
        I = np.sqrt(I)

        result = np.square(x).sum() / 4000 - np.cos(x / I).prod() + 1

        return result


class Rastrigin:
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -5.12 * np.ones(dims)  # [-5.12, 5.12]
        self.ub = 5.12 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1

        result = (np.square(x) - 10 * np.cos(2 * np.pi * x)).sum() + 10 * self.dims

        return result


class Schwefel:
    # Global Minimum x=(420.9687,...,420.9687)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -500 * np.ones(dims)  # [-500, 500]
        self.ub = 500 * np.ones(dims)
        self.counter = 0

        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        self.counter += 1
        x = np.asarray(x).reshape(-1)
        result = 418.9829 * self.dims - np.sum(x * np.sin(np.sqrt(np.absolute(x))))  + random.random()

        return result


class TridFunction:  # Bowl-Shaped
    # Global Minimum xi=i*(d+1-i) fx*=-d(d+4)(d-1)/6
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -dims * dims * np.ones(dims)  # [-d^2, d^2]
        self.ub = dims * dims * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        self.counter += 1
        x = np.array(x)
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        xd1 = x[:self.dims - 1]
        xd2 = x[1:self.dims]
        result = np.square(x - 1).sum() - np.sum(xd1 * xd2)

        return result


class Zakharov:  # Plate-Shaped
    # Global Minimum xi=0 fx*=-0
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -5 * np.ones(dims)  # [-5, 10]
        self.ub = 10 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        self.counter += 1
        x = np.array(x)
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        I = np.linspace(1, self.dims, num=self.dims)
        result = np.square(x).sum() + np.square(np.sum(I * x * 0.5)) + np.power(np.sum(I * x * 0.5), 4)

        return result


class Rosenbrock:  # Valley-Shaped
    # Global Minimum xi=1 fx*=-0
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -5 * np.ones(dims)  # [-5, 10]
        self.ub = 10 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims

        xd1 = x[:self.dims - 1]
        xd2 = x[1:self.dims]
        result = np.sum(np.square((xd2 - np.square(xd1))) * 100 + np.square(xd1 - 1))

        return result


class Michalewicz:  # Steep Ridges
    # Global Minimum d=2, xi=[2.2,1.57] fx*=-1.8031
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = np.zeros(dims)  # [0, pi]
        self.ub = np.pi * np.ones(dims)
        self.counter = 0

        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        self.counter += 1
        x = np.array(x)
        assert len(x) == self.dims

        I = np.linspace(1, self.dims, num=self.dims)
        m = 10
        result = -np.sum(np.sin(x) * np.power(np.sin(np.square(x) * I / np.pi), 2 * m))
        return result


class BentCigar:  # Bent Cigar Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims, dtype=np.float64)  # [-100, 100]
        self.ub = 100 * np.ones(dims, dtype=np.float64)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)  # , dtype=np.float64
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        xd1 = x[0]
        xd2 = x[1:self.dims]
        result = np.square(xd1).sum() + np.square(xd2).sum() * (10 ** 6)

        return result


class Elliptic:  # High Conditioned Elliptic Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        I = np.linspace(0, 1, num=self.dims)
        d = np.power((10 ** 6), I)
        result = np.inner(np.square(x), d)

        return result


class HGBat:  # HGBat Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0

        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        part1 = np.abs((np.square(np.square(x).sum()) - np.square(np.sum(x)))) ** 0.5
        part2 = 0.5 * np.square(x).sum() + np.sum(x) / self.dims + 0.5
        result = part1 + part2

        return result


class Happycat:  # Happycat Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0

        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        part1 = np.abs(np.square(x).sum() - self.dims) ** 0.25
        part2 = 0.5 * np.square(x).sum() + np.sum(x) / self.dims + 0.5
        result = part1 + part2

        return result


class Discus:  # Discus Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0

        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        xd1 = x[0]
        xd2 = x[1:self.dims]
        part1 = np.square(xd1).sum() * (10 ** 6)
        part2 = np.square(xd2).sum()
        result = part1 + part2

        return result

class Schaffer:  # Modified Schwefel’s Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=2):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        xd1 = x[0]
        xd2 = x[1]
        part1 = np.square(np.sin((np.square(xd1) + np.square(xd2)) ** 0.5)) - 0.5
        part2 = np.square(1 + 0.001 * (np.square(xd1) + np.square(xd2)))
        result = 0.5 + part1 / part2

        return result


class ExpSchaffer:  # Expanded Schaffer’s Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        result = 0
        for i in range(0, self.dims):
            xd1 = x[i]
            if i < self.dims - 1:
                xd2 = x[i + 1]
            else:
                xd2 = x[0]
            xd = [xd1, xd2]
            fun = Schaffer(dims=2)
            result = fun(xd) + result

        return result


class ExpRosenbrock:  # Expanded Rosenbrock’s plus Griewangk’s Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        result = 0
        for i in range(0, self.dims):
            xd1 = x[i]
            if i < self.dims - 1:
                xd2 = x[i + 1]
            else:
                xd2 = x[0]
            xd = [xd1, xd2]
            fun1 = Rosenbrock(dims=2)
            fun2 = GrieWank(dims=1)
            temp = [fun1(xd)]
            result = fun2(temp) + result

        return result


class Weierstrass:  # Weierstrass Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)

        result = 0
        a = 0.5
        b = 3
        kmax = 20
        K = np.linspace(1, kmax, num=kmax)
        A = np.power(a, K)
        B = np.power(b, K)

        part1 = 0
        for i in range(0, self.dims):
            xd1 = x[i]
            part1 = np.sum(A * np.cos(2 * np.pi * B * (xd1 + 0.5)))
            part1 = part1 + part1
        part2 = self.dims * np.sum(A * np.cos(2 * np.pi * B * 0.5))
        result = part1 - part2
        return result


class Composition1:  # Ackley’s Function, High Conditioned Elliptic Function, Griewank’s Function, Rastrigin’s Function
    # Global Minimum x=(0,...,0)
    def __init__(self, dims=10):
        self.dims = dims
        self.lb = -100 * np.ones(dims)  # [-100, 100]
        self.ub = 100 * np.ones(dims)
        self.counter = 0
        self.Cp = 1
        self.leaf_size = 2 * dims
        self.ninits = 5 * dims
        self.kernel_type = "rbf"
        self.gamma_type = "auto"

    def __call__(self, x):
        x = np.array(x)
        self.counter += 1
        assert len(x) == self.dims
        assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        g1 = Ackley(dims=self.dims)
        g2 = Elliptic(dims=self.dims)
        g3 = Rastrigin(dims=self.dims)
        g4 = GrieWank(dims=self.dims)

        Fstar = 2400
        seta = np.array([10, 20, 30, 40])
        gama = [10, 0.000006, 10, 1]
        bias = [0, 100, 200, 300]
        # o = [0,...,0] #set shifted optimum position into zeros
        W = (1 / (np.square(x).sum() ** 0.5)) * (np.exp(-1 * np.square(x).sum() / (2 * self.dims * seta)))
        W = W / (W.sum())

        G = np.array([g1(x), g2(x), g3(x), g4(x)])
        result = np.sum(W * (gama * G + bias)) + Fstar
        return result


class Swimmer:

    def __init__(self):
        self.policy_shape = (2, 8)
        self.mean = 0
        self.std = 0.1
        self.dims = 16
        self.lb = -1 * np.ones(self.dims)
        self.ub = 1 * np.ones(self.dims)
        self.counter = 0
        self.env = gym.make('Swimmer-v2')
        self.num_rollouts = 3
        self.Cp = 20
        self.leaf_size = 10
        self.kernel_type = "poly"
        self.gamma_type = "scale"
        self.ninits = 40
        print("===========initialization===========")
        print("mean:", self.mean)
        print("std:", self.std)
        print("dims:", self.dims)
        print("policy:", self.policy_shape)

        self.render = False

    def __call__(self, x):
        self.counter += 1
        assert len(x) == self.dims
        # assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        x = np.array(x)

        M = x.reshape(self.policy_shape)

        returns = []
        observations = []
        actions = []

        for i in range(self.num_rollouts):
            obs = self.env.reset()
            done = False
            totalr = 0.
            steps = 0

            while not done:

                # action = np.dot(M, (obs - self.mean) / self.std)
                action = np.dot(M, obs)
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = self.env.step(action)
                totalr += r
                steps += 1
                if self.render:
                    self.env.render()
            returns.append(totalr)

        return np.mean(returns) * -1


class Hopper:

    def __init__(self):
        self.mean = np.array([1.41599384, -0.05478602, -0.25522216, -0.25404721,
                              0.27525085, 2.60889529, -0.0085352, 0.0068375,
                              -0.07123674, -0.05044839, -0.45569644])
        self.std = np.array([0.19805723, 0.07824488, 0.17120271, 0.32000514,
                             0.62401884, 0.82814161, 1.51915814, 1.17378372,
                             1.87761249, 3.63482761, 5.7164752])
        self.dims = 33
        self.lb = -1 * np.ones(self.dims)
        self.ub = 1 * np.ones(self.dims)
        self.counter = 0
        self.env = gym.make('Hopper-v2')
        self.num_rollouts = 3
        self.render = False
        self.policy_shape = (3, 11)

        self.Cp = 10
        self.leaf_size = 100
        self.kernel_type = "poly"
        self.gamma_type = "auto"
        self.ninits = 150

        print("===========initialization===========")
        print("mean:", self.mean)
        print("std:", self.std)
        print("dims:", self.dims)
        print("policy:", self.policy_shape)

    def __call__(self, x):
        self.counter += 1
        assert len(x) == self.dims
        # assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        x = np.array(x)

        M = x.reshape(self.policy_shape)

        returns = []
        observations = []
        actions = []

        for i in range(self.num_rollouts):
            obs = self.env.reset()
            done = False
            totalr = 0.
            steps = 0
            while not done:
                # M      = self.policy
                # inputs = (obs - self.mean) / self.std
                inputs = obs
                action = np.dot(M, inputs)
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = self.env.step(action)
                totalr += r
                steps += 1
                if self.render:
                    self.env.render()
            returns.append(totalr)

        return np.mean(returns) * -1


class Walker:

    def __init__(self):
        self.mean = 0
        self.std = 1
        self.dims = 102
        self.lb = -1 * np.ones(self.dims)
        self.ub = 1 * np.ones(self.dims)
        self.counter = 0
        self.env = gym.make('Walker2d')
        self.num_rollouts = 3
        self.render = False
        self.policy_shape = (6, 17)

        self.Cp = 10
        self.leaf_size = 100
        self.kernel_type = "poly"
        self.gamma_type = "auto"
        self.ninits = 150

        print("===========initialization===========")
        print("mean:", self.mean)
        print("std:", self.std)
        print("dims:", self.dims)
        print("policy:", self.policy_shape)

    def __call__(self, x):
        self.counter += 1
        assert len(x) == self.dims
        # assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        x = np.array(x)

        M = x.reshape(self.policy_shape)

        returns = []
        observations = []
        actions = []

        for i in range(self.num_rollouts):
            obs = self.env.reset()
            done = False
            totalr = 0.
            steps = 0
            while not done:
                # M      = self.policy
                # inputs = (obs - self.mean) / self.std
                inputs = obs
                action = np.dot(M, inputs)
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = self.env.step(action)
                totalr += r
                steps += 1
                if self.render:
                    self.env.render()
            returns.append(totalr)

        return np.mean(returns) * -1


class HalfCheetah:

    def __init__(self):
        self.mean = 0
        self.std = 0.1
        self.dims = 102
        self.lb = -1 * np.ones(self.dims)
        self.ub = 1 * np.ones(self.dims)
        self.counter = 0
        self.env = gym.make('HalfCheetah-v3')
        self.num_rollouts = 3
        self.render = False
        self.policy_shape = (6, 17)

        self.Cp = 10
        self.leaf_size = 100
        self.kernel_type = "poly"
        self.gamma_type = "auto"
        self.ninits = 150

        print("===========initialization===========")
        print("mean:", self.mean)
        print("std:", self.std)
        print("dims:", self.dims)
        print("policy:", self.policy_shape)

    def __call__(self, x):
        self.counter += 1
        assert len(x) == self.dims
        # assert x.ndim == 1
        assert np.all(x <= self.ub) and np.all(x >= self.lb)
        x = np.array(x)

        M = x.reshape(self.policy_shape)

        returns = []
        observations = []
        actions = []

        for i in range(self.num_rollouts):
            obs = self.env.reset()
            done = False
            totalr = 0.
            steps = 0
            while not done:
                inputs = obs
                action = np.dot(M, inputs)
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = self.env.step(action)
                totalr += r
                steps += 1
                if self.render:
                    self.env.render()
            returns.append(totalr)

        return np.mean(returns) * -1



